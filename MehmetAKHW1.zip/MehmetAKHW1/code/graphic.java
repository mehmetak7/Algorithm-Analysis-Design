/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.scene.Scene;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

/**
 *
 * @author mehmet ak
 */
public class graphic extends Application {

    static double matrix[][] = new double[5][2];

    @Override
    public void start(Stage stage) throws Exception {
        init(stage);

    }

    public void init(Stage stage) {
        HBox root = new HBox();
        Scene scene = new Scene(root, 500, 700);
        //450-350
        CategoryAxis xAxis = new CategoryAxis();
        xAxis.setLabel("Size of Arrays");

        NumberAxis yAxis = new NumberAxis();
        yAxis.setLabel("Algorithm's Sorting Time");

        LineChart<String, Number> lineChart = new LineChart<String, Number>(xAxis, yAxis);
        lineChart.setTitle("Result of Algotirhtm's Time and Size");

        XYChart.Series<String, Number> data = new XYChart.Series<>();
        data.getData().add(new XYChart.Data<String, Number>("100", matrix[0][1]));
        data.getData().add(new XYChart.Data<String, Number>("1000", matrix[1][1]));
        data.getData().add(new XYChart.Data<String, Number>("10000", matrix[2][1]));
        data.getData().add(new XYChart.Data<String, Number>("50000", matrix[3][1]));
        data.getData().add(new XYChart.Data<String, Number>("100000", matrix[4][1]));

        lineChart.getData().add(data);
        root.getChildren().add(lineChart);

        stage.setTitle("Sorting Time Algorithm");
        stage.setScene(scene);
        stage.show();

    }

    public static void main(String[] args) {

        launch();
    }

}
