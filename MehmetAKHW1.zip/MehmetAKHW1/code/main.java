
import java.util.ArrayList;
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author mehmet ak
 */
public class main {

    static double matrix[][] = new double[5][2];

    public static void main(String[] args) {

        double heap_result[][] = new double[5][2];
        double select_result[][] = new double[5][2];
        double Insert_result[][] = new double[5][2];
        double Merge_result[][] = new double[5][2];
        double Quick_result[][] = new double[5][2];
        double quickHoare_result[][] = new double[5][2];
        int[] size = new int[]{100, 1000, 10000, 50000, 100000};

        for (int i = 0; i < select_result.length; i++) {

            heap_result[i][0] = size[i];
            select_result[i][0] = size[i];
            Insert_result[i][0] = size[i];
            Merge_result[i][0] = size[i];
            Quick_result[i][0] = size[i];
            quickHoare_result[i][0] = size[i];

        }

        int Parameters1[] = new int[100];
        RandomArray(Parameters1.length, Parameters1);
        int Parameters2[] = new int[1000];
        RandomArray(Parameters2.length, Parameters2);
        int Parameters3[] = new int[10000];
        RandomArray(Parameters3.length, Parameters3);
        int Parameters4[] = new int[50000];
        RandomArray(Parameters4.length, Parameters4);
        int Parameters5[] = new int[100000];
        RandomArray(Parameters5.length, Parameters5);

        int Sorted1[] = new int[100];
        SortedArray(Sorted1.length, Sorted1);
        int Sorted2[] = new int[1000];
        SortedArray(Sorted2.length, Sorted2);
        int Sorted3[] = new int[10000];
        SortedArray(Sorted3.length, Sorted3);
        int Sorted4[] = new int[50000];
        SortedArray(Sorted4.length, Sorted4);
        int Sorted5[] = new int[100000];
        SortedArray(Sorted5.length, Sorted5);

        int Reversed1[] = new int[100];
        ReverseddArray(Reversed1.length, Reversed1);
        int Reversed2[] = new int[1000];
        ReverseddArray(Reversed2.length, Reversed2);
        int Reversed3[] = new int[10000];
        ReverseddArray(Reversed3.length, Reversed3);
        int Reversed4[] = new int[50000];
        ReverseddArray(Reversed4.length, Reversed4);
        int Reversed5[] = new int[100000];
        ReverseddArray(Reversed5.length, Reversed5);

        ArrayList dizilerList = new ArrayList();
        dizilerList.add(Parameters1);
        dizilerList.add(Parameters2);
        dizilerList.add(Parameters3);
        dizilerList.add(Parameters4);
        dizilerList.add(Parameters5);

        ArrayList sortedList = new ArrayList();
        sortedList.add(Sorted1);
        sortedList.add(Sorted2);
        sortedList.add(Sorted3);
        sortedList.add(Sorted4);
        sortedList.add(Sorted5);

        ArrayList ReversedList = new ArrayList();
        ReversedList.add(Reversed1);
        ReversedList.add(Reversed2);
        ReversedList.add(Reversed3);
        ReversedList.add(Reversed4);
        ReversedList.add(Reversed5);

        Scanner sc = new Scanner(System.in);
        Boolean kontrol = true;
        while (kontrol) {

            System.out.println("Lütfen hangi arrayler üzerinde çalışmak istediğinizi seçiniz..\n"
                    + "1 -> Random Arrays\n"
                    + "2 -> Sorted Arrays\n"
                    + "3 -> Reversed Arrays\n"
                    + "Lütfen bir tuşlama yapınız : ");
            int type = sc.nextInt();

            System.out.println("Lütfen grafiğini görmek istediğiniz sort algoritma seçenegini tuşlayınız...\n"
                    + "1 -> Heap sort\n"
                    + "2 -> Selection Sort\n"
                    + "3 -> Insertion Sort\n"
                    + "4 -> Merge Sort\n"
                    + "5 -> Quick Sort with Lomuto\n"
                    + "6 -> Quick with Hoare's Partition\n"
                    + "0 -> Exit\n"
                    + "Lütfen bir tuşlama yapınız : ");
            int input = sc.nextInt();

            if (input == 1) {

                heap objHeap = new heap();
                System.out.println("--------Heap---------");
                for (int i = 0; i < dizilerList.size(); i++) {
                    long time1 = System.nanoTime();
                    if (type == 1) {
                        objHeap.heapSort((int[]) dizilerList.get(i));
                    } else if (type == 2) {
                        objHeap.heapSort((int[]) sortedList.get(i));
                    } else if (type == 3) {
                        objHeap.heapSort((int[]) ReversedList.get(i));
                    }
                    long time2 = System.nanoTime();
                    double diff = (double) ((time2 - time1) / (1000000.0)); //2 sıfır sildim.
                    heap_result[i][1] = diff;

                }
                for (int i = 0; i < heap_result.length; i++) {
                    System.out.println(size[i] + " boyutlu array için -> " + heap_result[i][1]);
                }
                graphic.matrix = heap_result;
                graphic.main(null);
            } else if (input == 2) {
                selection objSelection = new selection();
                System.out.println("--------Selection---------");
                for (int i = 0; i < dizilerList.size(); i++) {
                    long time1 = System.nanoTime();
                    if (type == 1) {
                        objSelection.selectionSort((int[]) dizilerList.get(i));
                    } else if (type == 2) {
                        objSelection.selectionSort((int[]) sortedList.get(i));
                    } else if (type == 3) {
                        objSelection.selectionSort((int[]) ReversedList.get(i));
                    }
                    long time2 = System.nanoTime();
                    //objSelection.display(dizi);
                    double diff = (double) ((time2 - time1) / (1000000.0)); //2 sıfır sildim.
                    select_result[i][1] = diff;

                }
                for (int i = 0; i < select_result.length; i++) {
                    System.out.println(size[i] + " boyutlu array için -> " + select_result[i][1]);
                }
                graphic.matrix = select_result;
                graphic.main(null);

            } else if (input == 3) {
                System.out.println("--------Insert---------");
                insertion objInsert = new insertion();
                for (int i = 0; i < dizilerList.size(); i++) {
                    long time1 = System.nanoTime();
                    if (type == 1) {
                        objInsert.sort((int[]) dizilerList.get(i));
                    } else if (type == 2) {
                        objInsert.sort((int[]) sortedList.get(i));
                    } else if (type == 3) {
                        objInsert.sort((int[]) ReversedList.get(i));
                    }
                    long time2 = System.nanoTime();
                    double diff = (double) ((time2 - time1) / (1000000.0)); //2 sıfır sildim.
                    Insert_result[i][1] = diff;

                }
                for (int i = 0; i < Insert_result.length; i++) {
                    System.out.println(size[i] + " boyutlu array için -> " + Insert_result[i][1]);
                }
                graphic.matrix = Insert_result;
                graphic.main(null);

            } else if (input == 4) {
                merge objMerge = new merge();
                System.out.println("--------Merge---------");
                for (int i = 0; i < dizilerList.size(); i++) {
                    long time1 = System.nanoTime();
                    if (type == 1) {
                        objMerge.mergeSort((int[]) dizilerList.get(i), 0, size[i] - 1);
                    } else if (type == 2) {
                        objMerge.mergeSort((int[]) sortedList.get(i), 0, size[i] - 1);
                    } else if (type == 3) {
                        objMerge.mergeSort((int[]) ReversedList.get(i), 0, size[i] - 1);
                    }
                    long time2 = System.nanoTime();
                    //objMerge.display(dizi);
                    double diff = (double) ((time2 - time1) / (1000000.0)); //2 sıfır sildim.
                    Merge_result[i][1] = diff;

                }
                for (int i = 0; i < Merge_result.length; i++) {
                    System.out.println(size[i] + " boyutlu array için -> " + Merge_result[i][1]);
                }
                graphic.matrix = Merge_result;
                graphic.main(null);

            } else if (input == 5) {
                quickWithLomuto objQuick = new quickWithLomuto();
                System.out.println("--------Quick Sort With Lomuto Partition---------");
                for (int i = 0; i < dizilerList.size(); i++) {
                    long time1 = System.nanoTime();
                    if (type == 1) {
                        objQuick.quickSort((int[]) dizilerList.get(i));
                    } else if (type == 2) {
                        objQuick.quickSort((int[]) sortedList.get(i));
                    } else if (type == 3) {
                        objQuick.quickSort((int[]) ReversedList.get(i));
                    }
                    long time2 = System.nanoTime(); //objMerge.display(dizi);
                    double diff = (double) ((time2 - time1) / (1000000.0)); //2 sıfır sildim.
                    Quick_result[i][1] = diff;
                }
                for (int i = 0; i < Quick_result.length; i++) {
                    System.out.println(size[i] + " boyutlu array için -> " + Quick_result[i][1]);
                }
                graphic.matrix = Quick_result;
                graphic.main(null);
            } else if (input == 6) {
                quickSortWithHoare objHoare = new quickSortWithHoare();
                System.out.println("--------Quick Sort With Hoare's Partition---------");
                for (int i = 0; i < dizilerList.size(); i++) {
                    long time1 = System.nanoTime();
                    if (type == 1) {
                        objHoare.sort((int[]) dizilerList.get(i));
                    } else if (type == 2) {
                        objHoare.sort((int[]) sortedList.get(i));
                    } else if (type == 3) {
                        objHoare.sort((int[]) ReversedList.get(i));
                    }
                    long time2 = System.nanoTime();
                    //objSelection.display(dizi);
                    double diff = (double) ((time2 - time1) / (1000000.0)); //2 sıfır sildim.
                    quickHoare_result[i][1] = diff;
                }
                for (int i = 0; i < Merge_result.length; i++) {
                    System.out.println(size[i] + " boyutlu array için -> " + quickHoare_result[i][1]);
                }
                graphic.matrix = quickHoare_result;
                graphic.main(null);
            } else if (input == 0) {
                kontrol = false;
            } else {
                System.out.println("Lütfen tekrardan doğru seçim yapınız..");
            }

        }
    }

    static void RandomArray(int size, int gelen_dizi[]) {

        for (int i = 0; i < size; i++) {
            gelen_dizi[i] = (int) (Math.random() * 100 + 1);
        }
    }

    static void SortedArray(int size, int gelen_dizi[]) {

        for (int i = 0; i < size; i++) {
            gelen_dizi[i] = i + 1;
        }
    }

    static void ReverseddArray(int size, int gelen_dizi[]) {

        for (int i = 0; i < size; i++) {
            gelen_dizi[i] = size - i;
        }
    }

}
